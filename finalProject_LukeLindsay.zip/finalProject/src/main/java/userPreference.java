

import java.io.Serializable;
import java.util.Arrays;

public class userPreference implements Serializable {
    private String[] genres;
    private String actorsActresses;

    public userPreference() {
        // Default constructor
    }

    public userPreference(String[] genres, String actorsActresses) {
        this.genres = genres;
        this.actorsActresses = actorsActresses;
    }

    public String[] getGenres() {
        return genres;
    }

    public void setGenres(String[] genres) {
        this.genres = genres;
    }

    public String getActorsActresses() {
        return actorsActresses;
    }

    public void setActorsActresses(String actorsActresses) {
        this.actorsActresses = actorsActresses;
    }

    @Override
    public String toString() {
        return "UserPreferences{" +
                "genres=" + Arrays.toString(genres) +
                ", actorsActresses='" + actorsActresses + '\'' +
                '}';
    }
}
