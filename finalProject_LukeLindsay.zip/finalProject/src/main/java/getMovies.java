import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class getMovies {
    public void movieGenre(String genre) {
        try (Connection connection = databaseConnection.getConnection()) {
            String query = "SELECT title FROM Movies WHERE genre_id = " + "(SELECT genre_id FROM Genres WHERE name = ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, genre);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println(resultSet.getString("title"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
