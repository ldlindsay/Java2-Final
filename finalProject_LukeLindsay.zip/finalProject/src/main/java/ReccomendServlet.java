import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;


public class ReccomendServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String[] genres = request.getParameterValues("genres");
        String actorsActresses = request.getParameter("actorsActresses");
        
        userPreference userPreferencesObject = new userPreference();
        userPreferencesObject.setGenres(genres);
        userPreferencesObject.setActorsActresses(actorsActresses);
        
        request.setAttribute("genres", genres);
        request.setAttribute("actorsActresses", actorsActresses);
        
        HttpSession session = request.getSession();
        session.setAttribute("userPreferences", userPreferencesObject);

    }
}

